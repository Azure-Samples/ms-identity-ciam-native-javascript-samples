export declare const name = "@azure/msal-browser";
export declare const version = "4.21.0";
//# sourceMappingURL=packageMetadata.d.ts.map