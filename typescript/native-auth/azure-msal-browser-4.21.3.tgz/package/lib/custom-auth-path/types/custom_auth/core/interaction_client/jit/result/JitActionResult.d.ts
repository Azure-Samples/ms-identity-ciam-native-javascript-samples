import { AuthenticationResult } from "../../../../../response/AuthenticationResult.js";
import { AuthenticationMethod } from "../../../network_client/custom_auth_api/types/ApiResponseTypes.js";
interface JitActionResult {
    type: string;
    correlationId: string;
}
interface JitContinuationTokenResult extends JitActionResult {
    continuationToken: string;
}
export interface JitGetAuthMethodsResult extends JitContinuationTokenResult {
    type: typeof JIT_GET_AUTH_METHODS_RESULT_TYPE;
    authMethods: AuthenticationMethod[];
}
export interface JitVerificationRequiredResult extends JitContinuationTokenResult {
    type: typeof JIT_VERIFICATION_REQUIRED_RESULT_TYPE;
    challengeChannel: string;
    challengeTargetLabel: string;
    codeLength: number;
}
export interface JitCompletedResult extends JitActionResult {
    type: typeof JIT_COMPLETED_RESULT_TYPE;
    authenticationResult: AuthenticationResult;
}
export declare const JIT_GET_AUTH_METHODS_RESULT_TYPE = "JitGetAuthMethodsResult";
export declare const JIT_VERIFICATION_REQUIRED_RESULT_TYPE = "JitVerificationRequiredResult";
export declare const JIT_COMPLETED_RESULT_TYPE = "JitCompletedResult";
export declare function createJitGetAuthMethodsResult(input: Omit<JitGetAuthMethodsResult, "type">): JitGetAuthMethodsResult;
export declare function createJitVerificationRequiredResult(input: Omit<JitVerificationRequiredResult, "type">): JitVerificationRequiredResult;
export declare function createJitCompletedResult(input: Omit<JitCompletedResult, "type">): JitCompletedResult;
export {};
//# sourceMappingURL=JitActionResult.d.ts.map