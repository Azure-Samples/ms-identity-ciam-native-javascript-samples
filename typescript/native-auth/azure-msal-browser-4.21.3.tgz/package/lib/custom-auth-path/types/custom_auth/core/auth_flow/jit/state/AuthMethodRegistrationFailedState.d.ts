import { AuthFlowStateBase } from "../../AuthFlowState.js";
export declare class AuthMethodRegistrationFailedState extends AuthFlowStateBase {
}
//# sourceMappingURL=AuthMethodRegistrationFailedState.d.ts.map