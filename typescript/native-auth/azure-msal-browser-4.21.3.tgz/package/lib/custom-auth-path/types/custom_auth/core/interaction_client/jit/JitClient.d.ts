import { CustomAuthInteractionClientBase } from "../CustomAuthInteractionClientBase.js";
import { JitGetAuthMethodsParams, JitChallengeAuthMethodParams, JitSubmitChallengeParams } from "./parameter/JitParams.js";
import { JitGetAuthMethodsResult, JitVerificationRequiredResult, JitCompletedResult } from "./result/JitActionResult.js";
/**
 * JIT client for handling just-in-time authentication method registration flows.
 */
export declare class JitClient extends CustomAuthInteractionClientBase {
    /**
     * Gets available authentication methods for JIT registration.
     * @param parameters The parameters for getting auth methods.
     * @returns Promise that resolves to JitGetAuthMethodsResult.
     */
    getAuthMethods(parameters: JitGetAuthMethodsParams): Promise<JitGetAuthMethodsResult>;
    /**
     * Challenges an authentication method for JIT registration.
     * @param parameters The parameters for challenging the auth method.
     * @returns Promise that resolves to either JitVerificationRequiredResult or JitCompletedResult.
     */
    challengeAuthMethod(parameters: JitChallengeAuthMethodParams): Promise<JitVerificationRequiredResult | JitCompletedResult>;
    /**
     * Submits challenge response and completes JIT registration.
     * @param parameters The parameters for submitting the challenge.
     * @returns Promise that resolves to JitCompletedResult.
     */
    submitChallenge(parameters: JitSubmitChallengeParams): Promise<JitCompletedResult>;
}
//# sourceMappingURL=JitClient.d.ts.map