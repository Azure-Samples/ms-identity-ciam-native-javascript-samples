import { ResetPasswordClient } from "../../interaction_client/ResetPasswordClient.js";
import { SignInClient } from "../../../sign_in/interaction_client/SignInClient.js";
import { CustomAuthSilentCacheClient } from "../../../get_account/interaction_client/CustomAuthSilentCacheClient.js";
import { AuthFlowActionRequiredStateParameters } from "../../../core/auth_flow/AuthFlowState.js";
import { JitClient } from "../../../core/interaction_client/jit/JitClient.js";
export interface ResetPasswordStateParameters extends AuthFlowActionRequiredStateParameters {
    username: string;
    resetPasswordClient: ResetPasswordClient;
    signInClient: SignInClient;
    cacheClient: CustomAuthSilentCacheClient;
    jitClient: JitClient;
}
export type ResetPasswordPasswordRequiredStateParameters = ResetPasswordStateParameters;
export interface ResetPasswordCodeRequiredStateParameters extends ResetPasswordStateParameters {
    codeLength: number;
}
//# sourceMappingURL=ResetPasswordStateParameters.d.ts.map