import { AuthActionErrorBase } from "../../AuthFlowErrorBase.js";
declare abstract class AuthMethodRegistrationError extends AuthActionErrorBase {
    isRedirectRequired(): boolean;
}
/**
 * Error that occurred during authentication method challenge request.
 */
export declare class AuthMethodRegistrationChallengeMethodError extends AuthMethodRegistrationError {
    /**
     * Checks if the verification contact provided is incorrect.
     * @returns true if the verification contact is incorrect, false otherwise.
     */
    isIncorrectVerificationContact(): boolean;
}
/**
 * Error that occurred during authentication method challenge submission.
 */
export declare class AuthMethodRegistrationSubmitChallengeError extends AuthMethodRegistrationError {
    /**
     * Checks if the submitted challenge code is incorrect.
     * @returns true if the challenge code is incorrect, false otherwise.
     */
    isIncorrectChallenge(): boolean;
}
export {};
//# sourceMappingURL=AuthMethodRegistrationError.d.ts.map