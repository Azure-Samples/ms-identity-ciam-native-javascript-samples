import { AuthFlowStateBase } from "../../AuthFlowState.js";
export declare class AuthMethodRegistrationCompletedState extends AuthFlowStateBase {
}
//# sourceMappingURL=AuthMethodRegistrationCompletedState.d.ts.map